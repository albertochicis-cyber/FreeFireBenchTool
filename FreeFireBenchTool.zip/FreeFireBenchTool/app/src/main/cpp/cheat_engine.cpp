#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#define LOG_TAG "BenchCheatEngine"

struct Vec2 { float x = 0.0f; float y = 0.0f; };
struct Vec3 { float x = 0.0f; float y = 0.0f; float z = 0.0f; };

struct PlayerEntity {
    int32_t id = 0;
    std::string name;
    Vec3 headPos;
    Vec3 footPos;
    float distanceMeters = 0.0f;
    bool isEnemy = false;
    bool isAlive = false;
};

struct EngineConfig {
    bool aimbotHeadshot = false;
    bool espEnabled = false;
    bool espBoxes = true;
    bool espLines = true;
    bool espNames = true;
    bool espDistance = true;
    float aimbotFovPx = 180.0f;
    float aimbotSmooth = 0.25f;
    int screenWidth = 1920;
    int screenHeight = 1080;
};

namespace {
    std::mutex g_mutex;
    EngineConfig g_config;
    std::vector<PlayerEntity> g_entities;
    float g_viewMatrix[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};

    bool worldToScreen(const Vec3& world, Vec2& outScreen, const float* m, int w, int h) {
        float clipX = world.x * m[0] + world.y * m[4] + world.z * m[8] + m[12];
        float clipY = world.x * m[1] + world.y * m[5] + world.z * m[9] + m[13];
        float clipW = world.x * m[3] + world.y * m[7] + world.z * m[11] + m[15];
        if (clipW < 0.001f) return false;
        outScreen.x = (w * 0.5f) * ((clipX / clipW) + 1.0f);
        outScreen.y = (h * 0.5f) * (1.0f - (clipY / clipW));
        return (outScreen.x >= -200.0f && outScreen.x <= w + 200.0f &&
                outScreen.y >= -200.0f && outScreen.y <= h + 200.0f);
    }

    float dist2D(float x1, float y1, float x2, float y2) { return std::hypot(x2 - x1, y2 - y1); }
    float dist3D(const Vec3& a, const Vec3& b) {
        return std::sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) + (a.z-b.z)*(a.z-b.z));
    }
}

extern "C" {
JNIEXPORT void JNICALL
Java_com_bench_fftool_OverlayService_nativeSetConfig(
        JNIEnv*, jobject, jboolean aimbotHeadshot, jboolean espEnabled,
        jboolean espBoxes, jboolean espLines, jboolean espNames, jboolean espDistance,
        jfloat aimbotFovPx, jfloat aimbotSmooth, jint screenWidth, jint screenHeight) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_config.aimbotHeadshot = aimbotHeadshot;
    g_config.espEnabled = espEnabled;
    g_config.espBoxes = espBoxes;
    g_config.espLines = espLines;
    g_config.espNames = espNames;
    g_config.espDistance = espDistance;
    g_config.aimbotFovPx = std::clamp(aimbotFovPx, 20.0f, 800.0f);
    g_config.aimbotSmooth = std::clamp(aimbotSmooth, 0.02f, 1.0f);
    g_config.screenWidth = std::max(1, static_cast<int>(screenWidth));
    g_config.screenHeight = std::max(1, static_cast<int>(screenHeight));
}

JNIEXPORT jfloatArray JNICALL
Java_com_bench_fftool_OverlayService_nativeComputeFrame(
        JNIEnv* env, jobject, jfloat currentAimX, jfloat currentAimY) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const float cx = g_config.screenWidth * 0.5f;
    const float cy = g_config.screenHeight * 0.5f;
    int bestIndex = -1;
    float bestFovDist = g_config.aimbotFovPx;

    struct Projected { Vec2 h2; Vec2 f2; bool ok; float dist; bool enemy; int id; };
    std::vector<Projected> projList;
    for (size_t i = 0; i < g_entities.size(); ++i) {
        const auto& e = g_entities[i];
        if (!e.isAlive) continue;
        Projected p{};
        Vec2 h2, f2;
        bool hOk = worldToScreen(e.headPos, h2, g_viewMatrix, g_config.screenWidth, g_config.screenHeight);
        bool fOk = worldToScreen(e.footPos, f2, g_viewMatrix, g_config.screenWidth, g_config.screenHeight);
        p.h2 = h2; p.f2 = f2; p.ok = hOk && fOk; p.dist = e.distanceMeters; p.enemy = e.isEnemy; p.id = e.id;
        if (g_config.aimbotHeadshot && e.isEnemy && hOk) {
            float dC = dist2D(h2.x, h2.y, cx, cy);
            if (dC <= g_config.aimbotFovPx && dC < bestFovDist) {
                bestFovDist = dC;
                bestIndex = static_cast<int>(projList.size());
            }
        }
        projList.push_back(p);
    }

    float outAimX = currentAimX;
    float outAimY = currentAimY;
    int targetId = -1;
    if (bestIndex >= 0) {
        const auto& t = projList[bestIndex];
        targetId = t.id;
        float alpha = std::clamp(1.0f - (g_config.aimbotSmooth * 0.92f), 0.05f, 1.0f);
        outAimX = currentAimX + (t.h2.x - currentAimX) * alpha;
        outAimY = currentAimY + (t.h2.y - currentAimY) * alpha;
    }

    const jsize stride = 9;
    const jsize totalSize = 3 + static_cast<jsize>(projList.size()) * stride;
    jfloatArray result = env->NewFloatArray(totalSize);
    if (!result) return nullptr;
    std::vector<float> flat(totalSize, 0.0f);
    flat[0] = outAimX; flat[1] = outAimY; flat[2] = static_cast<float>(targetId);
    for (size_t i = 0; i < projList.size(); ++i) {
        const auto& p = projList[i];
        size_t b = 3 + i * stride;
        flat[b+0] = p.h2.x; flat[b+1] = p.h2.y; flat[b+2] = p.f2.x; flat[b+3] = p.f2.y;
        flat[b+4] = p.dist; flat[b+5] = p.enemy ? 1.0f : 0.0f;
        flat[b+6] = (static_cast<int>(i) == bestIndex) ? 1.0f : 0.0f;
        flat[b+7] = static_cast<float>(p.id); flat[b+8] = p.ok ? 1.0f : 0.0f;
    }
    env->SetFloatArrayRegion(result, 0, totalSize, flat.data());
    return result;
}
}
