cmake_minimum_required(VERSION 3.22.1)
project("cheat_engine")

add_library(
    cheat_engine
    SHARED
    cheat_engine.cpp
)

find_library(
    log-lib
    log
)

target_link_libraries(
    cheat_engine
    ${log-lib}
    android
)
