package com.bench.fftool

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class MenuState(
    val expanded: Boolean = true,
    val aimbotHeadshot: Boolean = false,
    val espEnabled: Boolean = false,
    val espBoxes: Boolean = true,
    val espLines: Boolean = true,
    val espNames: Boolean = true,
    val espDistance: Boolean = true,
    val aimbotFovPx: Float = 180f,
    val aimbotSmooth: Float = 0.25f,
    val adbHost: String = "127.0.0.1",
    val adbPairPort: String = "",
    val adbPairCode: String = "",
    val adbConnectPort: String = "5555",
    val adbStatus: String = "Sin conexion ADB"
)

@Composable
fun FloatingMenuPanel(
    state: MenuState,
    onStateChange: (MenuState) -> Unit,
    onPairAdb: () -> Unit,
    onConnectAdb: () -> Unit,
    onCloseService: () -> Unit
) {
    val bgDark = Color(0xFF101318)
    val cardDark = Color(0xFF181D26)
    val accent = Color(0xFF38BDF8)
    val textPrimary = Color(0xFFF1F5F9)
    val textMuted = Color(0xFF94A3B8)

    if (!state.expanded) {
        Box(modifier = Modifier.size(52.dp).clip(CircleShape).background(bgDark), contentAlignment = Alignment.Center) {
            IconButton(onClick = { onStateChange(state.copy(expanded = true)) }) {
                Icon(Icons.Default.Tune, contentDescription = "Abrir menu", tint = accent)
            }
        }
        return
    }

    var selectedTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier.width(340.dp).clip(RoundedCornerShape(16.dp)).background(bgDark).padding(12.dp).verticalScroll(rememberScrollState())
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("BENCH HUD // ARM64", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Android 14 Control Panel", color = textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Row {
                IconButton(onClick = { onStateChange(state.copy(expanded = false)) }, modifier = Modifier.size(32.dp)) {
                    Text("_", color = textMuted, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onCloseService, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Cerrar overlay", tint = textMuted, modifier = Modifier.size(18.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TabChip("Aimbot", selectedTab == 0, accent) { selectedTab = 0 }
            TabChip("ESP", selectedTab == 1, accent) { selectedTab = 1 }
            TabChip("ADB", selectedTab == 2, accent) { selectedTab = 2 }
        }
        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = Color(0xFF232A36))
        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTab) {
            0 -> {
                ToggleRow("Aimbot Headshot", "Prioriza cabeza dentro del FOV", state.aimbotHeadshot, accent) { onStateChange(state.copy(aimbotHeadshot = it)) }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Aimbot FOV: ${state.aimbotFovPx.toInt()} px", color = textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Slider(value = state.aimbotFovPx, onValueChange = { onStateChange(state.copy(aimbotFovPx = it)) }, valueRange = 40f..500f, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                Text("Aimbot Smooth: ${"%.2f".format(state.aimbotSmooth)}", color = textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Slider(value = state.aimbotSmooth, onValueChange = { onStateChange(state.copy(aimbotSmooth = it)) }, valueRange = 0.05f..0.95f, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
            }
            1 -> {
                ToggleRow("ESP Master", "Renderizado en pantalla", state.espEnabled, accent) { onStateChange(state.copy(espEnabled = it)) }
                ToggleRow("Cajas", "Bounding box 2D", state.espBoxes, accent) { onStateChange(state.copy(espBoxes = it)) }
                ToggleRow("Lineas", "Snaplines", state.espLines, accent) { onStateChange(state.copy(espLines = it)) }
                ToggleRow("Nombres", "Etiqueta", state.espNames, accent) { onStateChange(state.copy(espNames = it)) }
                ToggleRow("Distancia", "Metros (m)", state.espDistance, accent) { onStateChange(state.copy(espDistance = it)) }
            }
            2 -> {
                OutlinedTextField(value = state.adbHost, onValueChange = { onStateChange(state.copy(adbHost = it)) }, label = { Text("IP Host", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = state.adbPairPort, onValueChange = { onStateChange(state.copy(adbPairPort = it)) }, label = { Text("Pair Port", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = state.adbPairCode, onValueChange = { onStateChange(state.copy(adbPairCode = it)) }, label = { Text("Pair Code", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Button(onClick = onPairAdb, colors = ButtonDefaults.buttonColors(containerColor = cardDark), modifier = Modifier.fillMaxWidth()) { Text("Emparejar ADB", color = textPrimary, fontSize = 12.sp) }
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(value = state.adbConnectPort, onValueChange = { onStateChange(state.copy(adbConnectPort = it)) }, label = { Text("Debug Port", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(6.dp))
                Button(onClick = onConnectAdb, colors = ButtonDefaults.buttonColors(containerColor = accent), modifier = Modifier.fillMaxWidth()) { Text("Conectar ADB", color = Color(0xFF081018), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                Spacer(modifier = Modifier.height(8.dp))
                Text(state.adbStatus, color = textMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun TabChip(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) accent else Color(0xFF181D26), contentColor = if (selected) Color(0xFF081018) else Color(0xFFCBD5E1)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.height(34.dp)
    ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, accent: Color, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color(0xFFF1F5F9), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color(0xFF94A3B8), fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF081018), checkedTrackColor = accent))
    }
}
