package com.bench.fftool

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainScreen(
                hasOverlayPermission = { Settings.canDrawOverlays(this) },
                onRequestOverlayPermission = {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                },
                onStartOverlayService = {
                    if (!Settings.canDrawOverlays(this)) {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    } else {
                        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
                    }
                },
                onStopOverlayService = { stopService(Intent(this, OverlayService::class.java)) }
            )
        }
    }
}

@Composable
private fun MainScreen(
    hasOverlayPermission: () -> Boolean,
    onRequestOverlayPermission: () -> Unit,
    onStartOverlayService: () -> Unit,
    onStopOverlayService: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var overlayGranted by remember { mutableStateOf(hasOverlayPermission()) }
    var host by remember { mutableStateOf("127.0.0.1") }
    var pairPort by remember { mutableStateOf("") }
    var pairCode by remember { mutableStateOf("") }
    var connectPort by remember { mutableStateOf("5555") }
    var adbLog by remember { mutableStateOf("Listo para comprobar o emparejar ADB.") }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0B0E14)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("BENCH FF TOOL // ANDROID 14 (ARM64)", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("Panel de Control y Depuracion", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141923)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Permiso Overlay: ${if (overlayGranted) "CONCEDIDO" else "PENDIENTE"}",
                    color = if (overlayGranted) Color(0xFF22C55E) else Color(0xFFF59E0B),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onRequestOverlayPermission(); overlayGranted = hasOverlayPermission() }) {
                        Text("Permiso Overlay", color = Color.White)
                    }
                    Button(onClick = { overlayGranted = hasOverlayPermission(); onStartOverlayService() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8))) {
                        Text("Iniciar Menu", color = Color(0xFF071018), fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onStopOverlayService) {
                        Text("Detener", color = Color(0xFFF87171))
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141923)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Wireless Debugging (sin PC)", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("IP Host") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = pairPort, onValueChange = { pairPort = it }, label = { Text("Pair Port") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = pairCode, onValueChange = { pairCode = it }, label = { Text("Pair Code") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Button(onClick = {
                    val p = pairPort.trim().toIntOrNull()
                    if (!WirelessDebugManager.isValidIpv4(host) || p == null || pairCode.isBlank()) { adbLog = "Datos invalidos."; return@Button }
                    scope.launch { adbLog = "Emparejando..."; adbLog = WirelessDebugManager.pairDevice(host.trim(), p, pairCode).output }
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)), modifier = Modifier.fillMaxWidth()) {
                    Text("Emparejar ADB", color = Color.White)
                }
                OutlinedTextField(value = connectPort, onValueChange = { connectPort = it }, label = { Text("Debug Port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val p = connectPort.trim().toIntOrNull()
                    if (!WirelessDebugManager.isValidIpv4(host) || p == null) { adbLog = "IP o puerto invalidos."; return@Button }
                    scope.launch { adbLog = "Conectando..."; adbLog = WirelessDebugManager.connectDevice(host.trim(), p).output }
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)), modifier = Modifier.fillMaxWidth()) {
                    Text("Conectar ADB", color = Color(0xFF071018), fontWeight = FontWeight.Bold)
                }
                Text(adbLog, color = Color(0xFF94A3B8), fontSize = 12.sp)
            }
        }
    }
}
