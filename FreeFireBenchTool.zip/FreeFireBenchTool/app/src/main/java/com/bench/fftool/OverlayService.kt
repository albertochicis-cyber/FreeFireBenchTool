package com.bench.fftool

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.*
import kotlinx.coroutines.*

class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {
    companion object {
        init { System.loadLibrary("cheat_engine") }
        private const val CHANNEL_ID = "bench_overlay_channel"
        private const val NOTIF_ID = 1042
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var windowManager: WindowManager
    private var espView: EspCanvasView? = null
    private var menuView: ComposeView? = null
    private var menuState by mutableStateOf(MenuState())
    private var screenWidth = 1920
    private var screenHeight = 1080
    private var currentAimX = 960f
    private var currentAimY = 540f

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private external fun nativeSetConfig(
        aimbotHeadshot: Boolean, espEnabled: Boolean, espBoxes: Boolean,
        espLines: Boolean, espNames: Boolean, espDistance: Boolean,
        aimbotFovPx: Float, aimbotSmooth: Float, screenWidth: Int, screenHeight: Int
    )

    private external fun nativeComputeFrame(currentAimX: Float, currentAimY: Float): FloatArray

    private val frameLoop = object : Runnable {
        override fun run() {
            syncConfigToNative()
            val frameData = nativeComputeFrame(currentAimX, currentAimY)
            if (frameData.size >= 3) {
                currentAimX = frameData[0]
                currentAimY = frameData[1]
                espView?.updateFrame(frameData, menuState.aimbotHeadshot, menuState.aimbotFovPx, menuState.espEnabled, menuState.espBoxes, menuState.espLines, menuState.espNames, menuState.espDistance)
            }
            mainHandler.postDelayed(this, 16L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        currentAimX = screenWidth * 0.5f
        currentAimY = screenHeight * 0.5f

        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        attachEspCanvas()
        attachFloatingMenu()
        syncConfigToNative()
        mainHandler.post(frameLoop)
    }

    private fun syncConfigToNative() {
        nativeSetConfig(menuState.aimbotHeadshot, menuState.espEnabled, menuState.espBoxes, menuState.espLines, menuState.espNames, menuState.espDistance, menuState.aimbotFovPx, menuState.aimbotSmooth, screenWidth, screenHeight)
    }

    private fun attachEspCanvas() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        val view = EspCanvasView(this)
        espView = view
        windowManager.addView(view, params)
    }

    private fun attachFloatingMenu() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 140 }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                FloatingMenuPanel(
                    state = menuState,
                    onStateChange = { menuState = it; syncConfigToNative() },
                    onPairAdb = { handlePairAdb() },
                    onConnectAdb = { handleConnectAdb() },
                    onCloseService = { stopSelf() }
                )
            }
        }

        var initialX = 0; var initialY = 0; var tx = 0f; var ty = 0f
        composeView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { initialX = params.x; initialY = params.y; tx = event.rawX; ty = event.rawY; false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - tx).toInt(); val dy = (event.rawY - ty).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        params.x = initialX + dx; params.y = initialY + dy
                        try { windowManager.updateViewLayout(composeView, params) } catch (_: Exception) {}
                        true
                    } else false
                }
                else -> false
            }
        }
        menuView = composeView
        windowManager.addView(composeView, params)
    }

    private fun handlePairAdb() {
        val host = menuState.adbHost.trim(); val port = menuState.adbPairPort.trim().toIntOrNull(); val code = menuState.adbPairCode.trim()
        if (!WirelessDebugManager.isValidIpv4(host) || port == null || code.isEmpty()) { menuState = menuState.copy(adbStatus = "Datos invalidos."); return }
        serviceScope.launch { menuState = menuState.copy(adbStatus = "Emparejando..."); menuState = menuState.copy(adbStatus = WirelessDebugManager.pairDevice(host, port, code).output) }
    }

    private fun handleConnectAdb() {
        val host = menuState.adbHost.trim(); val port = menuState.adbConnectPort.trim().toIntOrNull()
        if (!WirelessDebugManager.isValidIpv4(host) || port == null) { menuState = menuState.copy(adbStatus = "IP o puerto invalidos."); return }
        serviceScope.launch { menuState = menuState.copy(adbStatus = "Conectando..."); menuState = menuState.copy(adbStatus = WirelessDebugManager.connectDevice(host, port).output) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "Bench Overlay Service", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("Bench FF ARM64 activo").setContentText("Overlay en ejecucion").setSmallIcon(android.R.drawable.ic_menu_compass).build()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(frameLoop); serviceScope.cancel()
        try { espView?.let { windowManager.removeView(it) }; menuView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class EspCanvasView(context: Context) : View(context) {
        private var frameData = FloatArray(0); private var showFov = false; private var fovPx = 180f; private var espEnabled = false
        private var showBoxes = true; private var showLines = true; private var showNames = true; private var showDistance = true
        private val fovPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; color = Color.argb(190, 56, 189, 248) }
        private val boxEnemyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.argb(235, 239, 68, 68) }
        private val boxTeamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; color = Color.argb(180, 34, 197, 94) }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.argb(180, 248, 250, 252) }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 28f; setShadowLayer(4f, 0f, 0f, Color.BLACK) }
        private val aimMarkerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.argb(230, 250, 204, 21) }

        fun updateFrame(data: FloatArray, showFov: Boolean, fovPx: Float, espEnabled: Boolean, showBoxes: Boolean, showLines: Boolean, showNames: Boolean, showDistance: Boolean) {
            frameData = data; this.showFov = showFov; this.fovPx = fovPx; this.espEnabled = espEnabled
            this.showBoxes = showBoxes; this.showLines = showLines; this.showNames = showNames; this.showDistance = showDistance
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width * 0.5f; val cy = height * 0.5f
            if (showFov) {
                canvas.drawCircle(cx, cy, fovPx, fovPaint)
                if (frameData.size >= 2 && frameData[0] > 0f && frameData[1] > 0f) canvas.drawCircle(frameData[0], frameData[1], 10f, aimMarkerPaint)
            }
            if (!espEnabled || frameData.size < 12) return
            val stride = 9; var idx = 3
            while (idx + stride <= frameData.size) {
                val hx = frameData[idx]; val hy = frameData[idx+1]; val fy = frameData[idx+3]
                val dist = frameData[idx+4]; val isEnemy = frameData[idx+5] > 0.5f; val isTarget = frameData[idx+6] > 0.5f
                val id = frameData[idx+7].toInt(); val valid = frameData[idx+8] > 0.5f
                if (valid) {
                    val bodyH = kotlin.math.max(20f, kotlin.math.abs(fy - hy)); val boxW = bodyH * 0.55f
                    val left = hx - boxW * 0.5f; val right = hx + boxW * 0.5f; val top = hy - bodyH * 0.15f
                    if (showBoxes) canvas.drawRect(left, top, right, fy, if (isTarget) aimMarkerPaint else if (isEnemy) boxEnemyPaint else boxTeamPaint)
                    if (showLines) canvas.drawLine(cx, height.toFloat(), hx, top, linePaint)
                    val parts = mutableListOf<String>()
                    if (showNames) parts.add("ID#$id")
                    if (showDistance) parts.add("${dist.toInt()}m")
                    if (parts.isNotEmpty()) canvas.drawText(parts.joinToString(" | "), left, top - 10f, textPaint)
                }
                idx += stride
            }
        }
    }
}
