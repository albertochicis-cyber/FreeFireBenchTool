package com.bench.fftool

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket
import java.util.concurrent.TimeUnit

data class WirelessDebugResult(val ok: Boolean, val output: String)

object WirelessDebugManager {
    fun isValidIpv4(host: String): Boolean {
        val parts = host.trim().split(".")
        if (parts.size != 4) return false
        return parts.all { (it.toIntOrNull() ?: -1) in 0..255 }
    }

    suspend fun checkPortReachable(host: String, port: Int, timeoutMs: Int = 1500): Boolean =
        withContext(Dispatchers.IO) {
            try {
                Socket().use { it.connect(java.net.InetSocketAddress(host, port), timeoutMs); true }
            } catch (_: Exception) { false }
        }

    suspend fun runAdbCommand(args: List<String>, timeoutSeconds: Long = 10): WirelessDebugResult =
        withContext(Dispatchers.IO) {
            try {
                val process = ProcessBuilder(listOf("adb") + args).redirectErrorStream(true).start()
                val sb = StringBuilder()
                BufferedReader(InputStreamReader(process.inputStream)).use { r ->
                    var line = r.readLine()
                    while (line != null) { sb.appendLine(line); line = r.readLine() }
                }
                if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                    process.destroyForcibly()
                    return@withContext WirelessDebugResult(false, "Tiempo agotado ejecutando adb.")
                }
                val code = process.exitValue()
                WirelessDebugResult(code == 0, sb.toString().trim().ifEmpty { "Codigo de salida: $code" })
            } catch (ex: Exception) {
                WirelessDebugResult(false, "ADB no disponible (${ex.message ?: "error"}).")
            }
        }

    suspend fun pairDevice(host: String, pairPort: Int, pairingCode: String) =
        runAdbCommand(listOf("pair", "$host:$pairPort", pairingCode.trim()))

    suspend fun connectDevice(host: String, debugPort: Int): WirelessDebugResult {
        if (!checkPortReachable(host, debugPort)) {
            return WirelessDebugResult(false, "Puerto $host:$debugPort no accesible.")
        }
        return runAdbCommand(listOf("connect", "$host:$debugPort"))
    }
}
